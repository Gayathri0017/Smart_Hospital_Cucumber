package com.actions;

public class AdminActions {

}
