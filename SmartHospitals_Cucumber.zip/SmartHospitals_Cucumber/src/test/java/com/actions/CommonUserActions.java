package com.actions;

public class CommonUserActions {

}
