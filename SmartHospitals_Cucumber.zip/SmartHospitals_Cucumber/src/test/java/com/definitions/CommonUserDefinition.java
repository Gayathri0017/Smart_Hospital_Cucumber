package com.definitions;

public class CommonUserDefinition {

}
