package com.definitions;

public class AdminDefinition {

}
